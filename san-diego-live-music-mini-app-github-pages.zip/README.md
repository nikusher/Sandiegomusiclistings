# San Diego Live Music Mini App

A static, GitHub Pages-friendly concert list.

## Run locally
Open `index.html` through a local web server (recommended because browsers may block fetches from `file://`):
`python3 -m http.server 8000`
Then open `http://localhost:8000`.

## Publish on GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html` and the `data/` folder.
3. Settings → Pages → Deploy from branch → choose `main` / root.
4. GitHub will give you the public Pages URL.

## Updating for a new date range
Replace `data/concerts.csv` with a CSV using the same columns:
`iso,date,venue,show,location,time,genre,price`

Keep unknown facts as `Not listed` rather than guessing.
